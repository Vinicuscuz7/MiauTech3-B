/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package miau.tech;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author jltyt
 */
public class Table extends AbstractTableModel {
   static ArrayList<Empresa> empresa = new ArrayList();
    
    String[] colunas = {"empresa", "cargo", "salario", "localizaçao"};
    
    public void cadastrarEmpresa(Empresa f) {
        empresa.add(f);
        this.fireTableDataChanged();
    }
    public Empresa returnEmpresa(int index) {
        return empresa.get(index);
        
    }
    public void alterarEmpresa(int index, Empresa f) {
        empresa.set(index, f);
        this.fireTableDataChanged();
    }
    
    public void removerEmpresa(int index) {
        empresa.remove(index);
        this.fireTableDataChanged();
    }
    
    @Override
    public int getRowCount() {
        return empresa.size();
    }

    @Override
    public int getColumnCount() {
      return colunas.length;
    }
    @Override
    public String getColumnName(int column){
        return colunas[column];
    }
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if(columnIndex == 0) {
            return empresa.get(rowIndex).getempresa();
        }else if (columnIndex == 1) {
            return empresa.get(rowIndex).getCargo();
        }else if(columnIndex == 2) {
            return empresa.get(rowIndex).getSalario();
        }else {
            return empresa.get(rowIndex).getLocalizaçao();
        }
    }
    
}
