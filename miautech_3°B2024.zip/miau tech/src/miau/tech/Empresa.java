/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package miau.tech;

/**
 *
 * @author jltyt
 */
public class Empresa {
    private String empresa;
    private String cargo;
    private double salario;
    private String localizaçao;
  
    public Empresa(String empresa, String cargo, double salario, String localizaçao){
        this.empresa = empresa;
        this.cargo = cargo;
        this.salario = salario;
        this.localizaçao = localizaçao;
    }
    public String getempresa(){
      return empresa;
  }
    public void setempresa(String empresa){
        this.empresa = empresa;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getLocalizaçao() {
        return localizaçao;
    }

    public void setLocalizaçao(String localizaçao) {
        this.localizaçao = localizaçao;
    }





}



